(() => {
  new Accordion(".accordion-container");
})();
